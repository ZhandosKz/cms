-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июл 04 2013 г., 17:57
-- Версия сервера: 5.5.27-log
-- Версия PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `test`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `test_multi_sets`()
    DETERMINISTIC
begin
        select user() as first_col;
        select user() as first_col, now() as second_col;
        select user() as first_col, now() as second_col, now() as third_col;
        end$$

CREATE DEFINER=`uti`@`localhost` PROCEDURE `test_num`()
BEGIN
    DECLARE var_num    VARCHAR(256);
    SET var_num  = (SELECT MAX(CAST(SUBSTRING(currency, 2) AS UNSIGNED)) FROM test WHERE currency LIKE 'w%');
    IF var_num IS NULL THEN
        SET var_num = 1;
    ELSE
        SET var_num = var_num + 1;
    END IF;
    SET var_num = CONCAT('w', LPAD(var_num, 6, 0));
    SELECT var_num;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `authassignment`
--

CREATE TABLE IF NOT EXISTS `authassignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `authitem`
--

CREATE TABLE IF NOT EXISTS `authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `authitem`
--

INSERT INTO `authitem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('reader', 2, '', NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `authitemchild`
--

CREATE TABLE IF NOT EXISTS `authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` mediumtext,
  `meta_d` varchar(255) DEFAULT NULL,
  `meta_k` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `is_homepage` tinyint(4) DEFAULT NULL,
  `published` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `content`
--

INSERT INTO `content` (`id`, `text`, `meta_d`, `meta_k`, `title`, `url`, `is_homepage`, `published`) VALUES
(3, '<p>КОНТЕНТ ГЛАВНОЙjhjgh<br></p>\r\n', '', '', 'Главная', NULL, 1, 1),
(4, '<p>\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc porta \r\nmetus eget dui rutrum tristique. Vivamus semper ultrices metus, nec \r\nconsequat eros egestas vitae. Cum sociis natoque penatibus et magnis dis\r\n parturient montes, nascetur ridiculus mus. Maecenas pellentesque velit \r\nac mauris cursus quis imperdiet erat suscipit. Quisque enim tellus, \r\nviverra eget aliquam in, sodales vitae leo. Sed vel lacus at metus \r\naliquam convallis. Proin dictum ultricies interdum. Fusce sit amet felis\r\n mi, non sodales ipsum. Aenean eu orci sed est feugiat cursus. \r\nSuspendisse potenti. Duis porta fringilla ipsum sollicitudin auctor. \r\nNunc semper, purus et scelerisque adipiscing, nunc orci tempus mauris, \r\nin dignissim massa mauris vel turpis. Nunc eu quam ante.\r\n</p>\r\n<p>\r\nNullam dictum ante et nisi semper consectetur interdum ante pharetra. \r\nInteger at tempus ligula. Vivamus semper cursus dui, eget dapibus ante \r\nrutrum nec. Mauris eu rutrum lectus. Curabitur porta tincidunt tortor, a\r\n pretium tellus dapibus quis. Mauris vestibulum eros magna, eu egestas \r\nlorem. Proin ac mauris eget magna tempus accumsan. Ut molestie enim a \r\nrisus viverra egestas. Quisque nec dolor a dui iaculis condimentum id \r\nsit amet tellus. Pellentesque ultrices, nulla eu tincidunt malesuada, \r\nipsum nunc faucibus dolor, non semper turpis est ac odio. Maecenas \r\nscelerisque odio a quam sagittis eget egestas risus mattis. Sed \r\nadipiscing, mauris sit amet sodales sollicitudin, tortor neque dignissim\r\n neque, quis cursus est lectus laoreet risus. Donec scelerisque sem nec \r\nmi accumsan accumsan. Mauris elementum nisi at nibh elementum vel \r\nhendrerit metus tempor.\r\n</p><p><br></p>\r\n', '', '', 'О себе', 'about', 0, 1),
(5, '<blockquote>gfdgfdgfdg<br></blockquote><p><br></p>', '', '', 'Страница', 'test', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `filename` varchar(4000) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 AUTO_INCREMENT=44 ;

--
-- Дамп данных таблицы `file`
--

INSERT INTO `file` (`id`, `mime_type`, `size`, `name`, `filename`, `object_id`, `description`) VALUES
(38, 'image/jpeg', 3667676, 'IMG_3355.JPG', '56789f597fb80b6f2e3d8fc06254e94eb284b3bd.JPG', 1, 'test'),
(39, 'image/jpeg', 3962891, 'IMG_3360.JPG', 'd52767c74aa4feef564ec929c1bb0726d1444dac.JPG', 1, ''),
(40, 'image/jpeg', 2779726, 'IMG_3370.JPG', '583aaf37ad8456a29756e1b219e64d1f0b64b6cd.JPG', 1, ''),
(41, 'image/jpeg', 101947, '11042012153.jpg', '5734a356e47834e7ccffbfa7b66ad9665c24cedc.jpg', 2, 'ппппп'),
(42, 'image/jpeg', 544197, ')1510.JPG', '23cf10b15cfe08409d39b601300f1badc898bd79.JPG', 2, 'ппппп'),
(43, 'image/jpeg', 77249, 'Bu.10164.jpg', 'e1dd97ed117aa1ce090cd990f690e18fb91507e9.jpg', 2, 'ппппп');

-- --------------------------------------------------------

--
-- Структура таблицы `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `published` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `interview`
--

CREATE TABLE IF NOT EXISTS `interview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iframe` varchar(5000) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `text` text,
  `published` tinyint(4) DEFAULT NULL,
  `iframe_thumbnail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `interview`
--

INSERT INTO `interview` (`id`, `iframe`, `title`, `file_id`, `text`, `published`, `iframe_thumbnail`) VALUES
(2, '<iframe width="560" height="315" src="http://www.youtube.com/embed/NbnnYMT5huk" frameborder="0" allowfullscreen></iframe>\n', 'trtert', NULL, '<p>bghfhg<br></p>', 0, '<iframe width="200" height="117" src="http://www.youtube.com/embed/NbnnYMT5huk" frameborder="0" allowfullscreen></iframe>\n'),
(4, NULL, 'trtert', NULL, NULL, 1, NULL),
(5, NULL, 'trtert', NULL, NULL, 1, NULL),
(6, NULL, 'trtert', NULL, NULL, 1, NULL),
(7, NULL, 'trtert', NULL, NULL, 1, NULL),
(8, NULL, 'trtert', NULL, NULL, 1, NULL),
(9, NULL, 'trtert', NULL, NULL, 1, NULL),
(10, NULL, 'trtert', NULL, NULL, 1, NULL),
(11, NULL, 'trtert', NULL, NULL, 1, NULL),
(12, NULL, 'trtert', NULL, NULL, 1, NULL),
(13, NULL, 'trtert', NULL, NULL, 1, NULL),
(14, NULL, 'trtert', NULL, NULL, 1, NULL),
(15, NULL, 'trtert', NULL, NULL, 1, NULL),
(16, NULL, 'trtert', NULL, NULL, 1, NULL),
(17, NULL, 'trtert', NULL, NULL, 1, NULL),
(18, NULL, 'trtert', NULL, NULL, 1, NULL),
(19, NULL, 'trtert', NULL, NULL, 1, NULL),
(20, NULL, 'trtert', NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`) VALUES
(1, 'superadmin', 'zhandos.90@gmail.com', 'zhandos.90@gmail.com'),
(2, 'admin', '123123', 'test@example.com'),
(3, 'test3', 'pass3', 'test3@example.com'),
(4, 'test4', 'pass4', 'test4@example.com'),
(5, 'test5', 'pass5', 'test5@example.com'),
(6, 'test6', 'pass6', 'test6@example.com'),
(7, 'test7', 'pass7', 'test7@example.com'),
(8, 'test8', 'pass8', 'test8@example.com'),
(9, 'test9', 'pass9', 'test9@example.com'),
(10, 'test10', 'pass10', 'test10@example.com'),
(11, 'test11', 'pass11', 'test11@example.com'),
(12, 'test12', 'pass12', 'test12@example.com'),
(13, 'test13', 'pass13', 'test13@example.com'),
(14, 'test14', 'pass14', 'test14@example.com'),
(15, 'test15', 'pass15', 'test15@example.com'),
(16, 'test16', 'pass16', 'test16@example.com'),
(17, 'test17', 'pass17', 'test17@example.com'),
(18, 'test18', 'pass18', 'test18@example.com'),
(19, 'test19', 'pass19', 'test19@example.com'),
(20, 'test20', 'pass20', 'test20@example.com'),
(21, 'test21', 'pass21', 'test21@example.com');

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `authassignment`
--
ALTER TABLE `authassignment`
  ADD CONSTRAINT `authassignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `authitemchild`
--
ALTER TABLE `authitemchild`
  ADD CONSTRAINT `authitemchild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `authitemchild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
